export { default as MyCommentItem } from './MyCommentItem';
