export { default as CommunityPost } from './CommunityPost';
