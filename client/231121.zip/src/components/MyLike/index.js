export { default as MyLike } from './MyLike';
