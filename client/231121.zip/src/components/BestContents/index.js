export { default as BestContents } from './BestContents';
