export { default as MyActivity } from './MyActivity';
