export { default as MyProfileImg } from './MyProfileImg';
