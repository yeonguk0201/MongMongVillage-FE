export { default as MyPost } from './MyPost';
