export { default as NewPost } from './NewPost';
