export { default as CommunityPostLike } from './CommunityPostLike';
