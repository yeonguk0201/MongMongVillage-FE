export { default as MyPageProfile } from './MyPageProfile';
