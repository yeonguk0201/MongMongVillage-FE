export { default as MyPostItem } from './MyPostItem';
