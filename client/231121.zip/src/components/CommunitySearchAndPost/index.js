export { default as CommunitySearchAndPost } from './CommunitySearchAndPost';
