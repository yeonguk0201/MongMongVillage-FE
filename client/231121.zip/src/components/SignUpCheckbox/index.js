export { default as SignUpCheckbox } from './SignUpCheckbox';
