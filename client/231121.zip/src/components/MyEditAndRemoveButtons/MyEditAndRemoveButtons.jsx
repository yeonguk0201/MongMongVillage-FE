import { Button } from './styles';

const MyEditAndRemoveButtons = () => {
  return (
    <div>
      <Button>수정</Button>
      <Button>삭제</Button>
    </div>
  );
};

export default MyEditAndRemoveButtons;
