export { default as NewPostPage } from './NewPostPage';
