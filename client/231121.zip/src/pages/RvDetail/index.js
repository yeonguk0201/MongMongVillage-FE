export { default as ReviewDetail } from "./ReviewDetail";
