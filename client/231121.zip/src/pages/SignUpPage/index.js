export { default as SignUpPage } from './SignUpPage';
