export { default as MyInfoEditPage } from './MyInfoEditPage';
