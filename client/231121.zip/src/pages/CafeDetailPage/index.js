export { default as CafeDetailPage } from './CafeDetailPage';
