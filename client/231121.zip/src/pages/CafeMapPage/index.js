export { default as CafeMapPage } from './CafeMapPage';
