export { default as MyPage } from './MyPage';
