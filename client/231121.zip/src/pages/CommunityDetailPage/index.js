export { default as CommunityDetailPage } from './CommunityDetailPage';
